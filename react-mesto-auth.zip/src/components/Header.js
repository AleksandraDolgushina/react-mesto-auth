import React from 'react'
import logoImg from '../images/logo.svg'
import { Route, Link } from 'react-router-dom';

function Header() {
    return (
        <header className="header">
            <img className="header__logo" src={logoImg} alt='Логотип'/>
            <Route path="/sign-up">
                <Link className="header__auth-link" to="sign-in">Войти</Link>
            </Route>
            <Route path="/sign-in">
                <Link className="header__auth-link" to="sign-up">Регистрация</Link>
            </Route>
        </header>
    )
}
export default Header;